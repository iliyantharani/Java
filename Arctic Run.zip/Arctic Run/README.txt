Steps to run group_13_assignment7:

Open Processing.
Make sure all provided files (Background.pde
Cactus.pde
Character.pde
coin.pde
Data
Hitbox.pde
Main.pde
sketch.properties
Sky.pde
Timer.pde
Title.pde
Tumbleweed.pde) are in the same directory.
Open the Main.pde file in Processing.
Click the "Run" button in the Processing interface to start the game.

Use the following commands to interact:
W: Jump
S: Slide
Spacebar: Make the player character jump.
A: Move left
D: Move right

